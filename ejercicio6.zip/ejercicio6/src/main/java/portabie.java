/*
 * UNIVERSIDAD DEL VALLE DE GUATEMALA
 * PROGRAMACION ORIENTADA A OBJETOS
 * EJERCICIO#6 
 * JAVIER ALEJANDRO PRADO RAMIREZ 21486 | ANGEL GABRIEL PEREZ FIGUEROA 21298
 * PROGRAMA UTILIZADO | APACHE NETBEANS
 * INGENIERIA EN CIENCIAS DE LA COMPUTACION Y TI

 */


/**
 *
 * interfaz de portabilidad del dispositivo
 */
public interface portabie {
    
    public void portable();
}
