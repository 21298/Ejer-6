/*
 * UNIVERSIDAD DEL VALLE DE GUATEMALA
 * PROGRAMACION ORIENTADA A OBJETOS
 * EJERCICIO#6 
 * JAVIER ALEJANDRO PRADO RAMIREZ 21486 | ANGEL GABRIEL PEREZ FIGUEROA 21298
 * PROGRAMA UTILIZADO | APACHE NETBEANS
 * IINGENIERIA EN CIENCIAS DE LA COMPUTACION Y TI

 */


/**
 *
 * Funcionalidad: Tiene como objetivo realizar compras y ventas pero en las diferentes tiendas que esta companía tenga, por eso es necesaria su direccion, pais, etc
 */

public class Sucursales {
    private String pais;
    
    
    
}
